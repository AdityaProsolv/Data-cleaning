# Data Cleaning & Visualization Project

## Objective
Clean a messy sales dataset, handle missing values, duplicates, and outliers, then create visual reports and extract business insights.

## Dataset
- Raw rows: 123
- Cleaned rows: 120
- Raw missing values: 10
- Duplicate rows removed: 3
- Outlier treatment: IQR-based capping on units, unit price, and revenue
- Missing categorical values: filled with mode
- Missing numeric values: filled with median

## Key Findings
1. **Total cleaned revenue:** 94,214.25
2. **Average revenue per order:** 785.12
3. **Top region:** East (32,596.75 revenue)
4. **Top category:** Furniture (36,176.25 revenue)
5. Revenue was reviewed over time, by region, and by category.
6. The rating/revenue scatter plot provides a quick check for whether higher-rated orders are associated with larger order values.

## Cleaning Decisions
- Text fields were trimmed and standardized to title case.
- Dates were converted to datetime.
- Missing region values were filled using the mode.
- Missing unit prices and customer ratings were filled using the median.
- Exact duplicate rows were removed.
- Numerical outliers were identified using the 1.5×IQR rule and capped rather than deleted so that potentially valid high-value transactions were retained.
- Revenue was recalculated from cleaned units, price, and discount.

## Deliverables
- `raw_sales_data.csv` — intentionally messy source data
- `cleaned_sales_data.csv` — cleaned and analysis-ready data
- `data_cleaning_visualization.ipynb` — full Python workflow
- `report.html` — readable project report
- `figures/` — visualizations
